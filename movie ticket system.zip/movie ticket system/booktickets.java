import java.awt.*;
import java.awt.event.*;

import javax.print.DocFlavor.STRING;
import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;

public class booktickets implements ActionListener {
    JPanel p;
    JLabel label;
    JButton movies[] = new JButton[5];

    String query;
    String[] m_name = new String[5];

    ResultSet res;

    public booktickets() {
        p = new JPanel();
        p.setSize(1366, 720);
        p.setLayout(null);
        p.setBorder(BorderFactory.createLineBorder(Color.black));
        label = new JLabel("MOVIES AVAILABLE :");
        label.setBounds(150, 150, 300, 60);
        label.setFont(new Font("Serif", Font.PLAIN, 20));
        p.add(label);

        query = "SELECT DISTINCT M_NAME FROM AVAIL";
        res = DB.query(query);
        int i = 0;
        try {
            while (res.next()) {
                m_name[i] = res.getString("M_NAME");
                JButton btn = new JButton(m_name[i]);
                btn.addActionListener(this);
                btn.setBounds(210, 210 + i * 50, 200, 50);

                movies[i] = btn;
                p.add(movies[i]);
                i++;
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        JButton logout = new JButton("Log Out");
        logout.setBounds(1230, 40, 100, 40);
        // logout.setBounds(600 + 300, 300, 200, 150);
        logout.addActionListener(this);
        p.add(logout);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals("Log Out")) {

            GUI.login();

        } else if (e.getActionCommand().equals("Book Tickets")) {

            GUI.booktickets();

        } else {
            Main.m_name = e.getActionCommand();
            try {
                query = "SELECT M_ID FROM AVAIL WHERE M_NAME='" + Main.m_name + "'"; //
                res = DB.query(query);
                res.next();
                Main.mid = res.getString("M_ID");
            } catch (Exception t) {
                System.out.println(t);
            }

            GUI.booking();
        }
    }

}