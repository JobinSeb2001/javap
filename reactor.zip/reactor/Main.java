public class Main {
	static String uid = "";
	static boolean printflag = true;

	public static void main(String[] args) {
		DB.connect();
		new GUI();
	}
}